#include "alu.h"


int nand(int a, int b)
{
	return !(a & b);
}


// Part 1: Logic Gates

int not(int a)
{
	// TODO 
	return -1;
}

int and(int a, int b)
{
	// TODO 
	return -1;
}

int or(int a, int b)
{
	// TODO 
	return -1;
}

int xor(int a, int b)
{
	// TODO 
	return -1;
}

int nor(int a, int b)
{
	// TODO 
	return -1;
}

int xnor(int a, int b)
{
	// TODO 
	return -1;
}

uint8_t bitwise_not(uint8_t a)
{
	// TODO 
	return 0;
}

uint8_t bitwise_and(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_or(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_xor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_nor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_xnor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}
