// Part 2: Arithmetic Circuits
#include "alu.h"

void half_adder(int a, int b, int *sum, int *carry)
{
	// TODO
	*sum   = -1;
	*carry = -1;
}

void full_adder(int a, int b, int cin, int *sum, int *cout)
{
	// TODO
	*sum  = -1;
	*cout = -1;
}

uint8_t ripple_add(uint8_t a, uint8_t b, int *overflow)
{
    // TODO
	return -1;
}
