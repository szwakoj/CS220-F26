#include "alu.h"


bit_t gate_nand(bit_t a, bit_t b)
{
    return !((a & 1) && (b & 1));
}


// Part 1: Logic Gates

bit_t gate_not(bit_t a)
{
	// TODO 
	return -1;
}

bit_t gate_and(bit_t a, bit_t b)
{
	// TODO 
	return -1;
}

bit_t gate_or(bit_t a, bit_t b)
{
	// TODO 
	return -1;
}

bit_t gate_xor(bit_t a, bit_t b)
{
	// TODO 
	return -1;
}

bit_t gate_nor(bit_t a, bit_t b)
{
	// TODO 
	return -1;
}

bit_t gate_xnor(bit_t a, bit_t b)
{
	// TODO 
	return -1;
}

uint8_t bitwise_not(uint8_t a)
{
	// TODO 
	return 0;
}

uint8_t bitwise_and(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_or(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_xor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_nor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}

uint8_t bitwise_xnor(uint8_t a, uint8_t b)
{
	// TODO 
	return 0;
}
