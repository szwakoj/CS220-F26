// Part 2: Arithmetic Circuits
#include "alu.h"

void half_adder(bit_t a, bit_t b, bit_t *sum, bit_t *carry)
{
	// TODO
	*sum   = -1;
	*carry = -1;
}

void full_adder(bit_t a, bit_t b, bit_t cin, bit_t *sum, bit_t *cout)
{
	// TODO
	*sum  = -1;
	*cout = -1;
}

uint8_t ripple_add(uint8_t a, uint8_t b, bit_t *overflow)
{
    // TODO
	return -1;
}

bit_t mux2_1_1_bit(bit_t sel, bit_t a, bit_t b)
{
    // TODO
	return -1;
}

uint8_t mux2_1_8bit(bit_t sel, uint8_t a, uint8_t b)
{
    // TODO
	return -1;
}

uint8_t mux4_1_8bit(bit_t sel0, bit_t sel1, uint8_t in0, uint8_t in1, uint8_t in2, uint8_t in3)
{
    // TODO
	return -1;
}


uint8_t alu(uint8_t a, uint8_t b, bit_t op1, bit_t op0)
{
	// TODO
	return -1;
}