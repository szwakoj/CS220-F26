#ifndef ALU_H
#define ALU_H

#include <stdint.h>

typedef uint8_t bit_t;

bit_t nand(bit_t a, bit_t b);

// gates.c

bit_t not(bit_t a);
bit_t and(bit_t a, bit_t b);
bit_t or(bit_t a, bit_t b);
bit_t xor(bit_t a, bit_t b);
bit_t nor(bit_t a, bit_t b);
bit_t xnor(bit_t a, bit_t b);

uint8_t bitwise_not(uint8_t a);
uint8_t bitwise_and(uint8_t a, uint8_t b);
uint8_t bitwise_or(uint8_t a, uint8_t b);
uint8_t bitwise_xor(uint8_t a, uint8_t b);
uint8_t bitwise_nor(uint8_t a, uint8_t b);
uint8_t bitwise_xnor(uint8_t a, uint8_t b);


// circuits.c

void half_adder(bit_t a, bit_t b, bit_t *sum, bit_t *carry);
void full_adder(bit_t a, bit_t b, bit_t cin, bit_t *sum, bit_t *cout);
uint8_t ripple_add(uint8_t a, uint8_t b, bit_t *overflow);

bit_t mux2_1bit(bit_t sel, bit_t a, bit_t b);
uint8_t mux2_8bit(bit_t sel, uint8_t a, uint8_t b);
uint8_t mux4_8bit(bit_t sel0, bit_t sel1, uint8_t in0, uint8_t in1, uint8_t in2, uint8_t in3);

uint8_t alu(uint8_t a, uint8_t b, bit_t op1, bit_t op0);

#endif /* ALU_H */
