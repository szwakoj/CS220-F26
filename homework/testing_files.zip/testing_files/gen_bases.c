#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const char* SYMBOLS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/";

int main(int argc, char const *argv[])
{
	srand(time(NULL));

	if(argc != 3) {
		printf("Error: Usage ./test_file_gen filename.txt number_of_lines");
	}

	FILE* fptr = fopen(argv[1], "w");

	int num = atoi(argv[2]);

	for(int i = 0 ; i <  num; i++) {
		int in_base = (rand() % 63) + 2;

		fprintf(fptr, "%d ", in_base);

		int len = (rand() % 10) + 1;

		for(int j = 0; j < len; j++) fputc(SYMBOLS[rand() % in_base], fptr);

		int out_base = (rand() % 63) + 2;

		while (out_base == in_base) out_base = (rand() % 63) + 2;

		fprintf(fptr, " %d", out_base);

		fprintf(fptr, "\n");
	}

	return 0;
}