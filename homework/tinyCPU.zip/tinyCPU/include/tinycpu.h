#pragma once

#include "RGFW.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

// ============== YOU DO THIS ==============
#define W
#define H
#define MEM_SIZE
#define REGS

typedef enum {
	LDI=0, MOV=1, LD=2, ST=3,
	ADD=4, SUB=5,
	AND=6, OR=7, XOR=8, NOT=9, LSL=10, LSR=11,
	JMP=12, JMPI=13, JNZ=14, JZ=15, HALT=16,
	DRAW=17, DRAWOFF=18, CLEAR=19
} Op;

// ============== YOU DO THIS ==============
typedef struct tinyCPU {
	//mem 	RAM memory bank
	//reg 	Register array
	//ir  	Instruction register array
	//pc 	Program Counter

	//halted Halt flag
	bool needs_render; // Render flag

	//screen 	2D Screen Buffer
} tinyCPU;

uint8_t alu_compute(Op op, uint8_t a, uint8_t b);
void cpu_draw_pixel(tinyCPU* cpu, uint8_t x, uint8_t y);
void cpu_render(tinyCPU* cpu);
void cpu_init(tinyCPU* cpu);
void cpu_load(tinyCPU* cpu, uint8_t* prog, size_t len);
void cpu_fetch(tinyCPU* cpu);
void cpu_decode_execute(tinyCPU* cpu);
void cpu_run(tinyCPU* cpu, int frame_delay_ms);